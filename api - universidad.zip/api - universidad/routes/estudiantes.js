const express = require('express');
const fs = require('fs');
const router = express.Router();

const filePath = './estudiantes.json';

// Leer todos los estudiantes
router.get('/', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    res.json(data);
});

// Consultar estudiante por ID
router.get('/:id', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    const estudiante = data.find(e => e.id == req.params.id);
    res.json(estudiante || { mensaje: "Estudiante no encontrado" });
});

// Crear estudiante
router.post('/', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    const nuevoEstudiante = {
        id: data.length + 1, // id secuencial
        nombre: req.body.nombre,
        apellido: req.body.apellido,
        direccion: req.body.direccion,
        fechaNacimiento: req.body.fechaNacimiento,
        semestre: req.body.semestre,
        foto: req.body.foto,
        materias: req.body.materias
    };
    data.push(nuevoEstudiante);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    res.json(nuevoEstudiante);
});


// Actualizar estudiante
router.put('/:id', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    const index = data.findIndex(e => e.id == req.params.id);
    if (index !== -1) {
        data[index] = { ...data[index], ...req.body };
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        res.json(data[index]);
    } else {
        res.json({ mensaje: "Estudiante no encontrado" });
    }
});

// Borrar estudiante
router.delete('/:id', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    const nuevoData = data.filter(e => e.id != req.params.id);
    fs.writeFileSync(filePath, JSON.stringify(nuevoData, null, 2));
    res.json({ mensaje: "Estudiante eliminado" });
});

// Consultar estudiantes por semestre
router.get('/semestre/:numero', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    const estudiantes = data.filter(e => e.semestre == req.params.numero);
    res.json(estudiantes);
});

// Consultar estudiantes por materia
router.get('/materia/:nombre', (req, res) => {
    const data = JSON.parse(fs.readFileSync(filePath));
    const nombreMateria = req.params.nombre.toLowerCase();
    const estudiantes = data.filter(e =>
        e.materias.some(m => m.toLowerCase() === nombreMateria)
    );
    res.json(estudiantes);
});

module.exports = router;
